require("dotenv").config()
const { Telegraf, Markup } = require('telegraf')
const text = require('./const')

const bot = new Telegraf(process.env.API_KEY)

bot.start(
    (ctx) => {
        ctx.replyWithHTML('<b>About bot!</b>', Markup.keyboard([
            ["menu", "audio"],
            ["video", "document"],
        ]).resize()
        )
    }
)

bot.help((ctx) => ctx.reply(text.commands))

bot.on("text", async (ctx) => {
    if (ctx.update.message.text === 'menu') {
        await ctx.replyWithHTML('<b>About menu!</b>', Markup.keyboard([
            ["foods", "drinks"]
        ]).oneTime().resize()
        )
    }

    if (ctx.update.message.text === 'foods') {
        await ctx.replyWithHTML('<b>About menu!</b>', Markup.keyboard([
            ["lavash", "hamburger"]
        ]).oneTime().resize()
        )

    }

    if (ctx.update.message.text === 'lavash') {
        ctx.replyWithPhoto('https://e7.pngegg.com/pngimages/374/414/png-clipart-shawarma-chicken-lavash-doner-kebab-pizza-chicken-food-animals-thumbnail.png', Markup.inlineKeyboard([
            [
                { text: "zakaz berish", callback_data: 'zakaz' },
                { text: "batafsil", callback_data: 'url' },
            ]
        ]))

    }

    if (ctx.update.message.text === 'contact') {
        ctx.replyWithContact('+998999999999', ctx.update.message.from.first_name)

    }

})

bot.on('sticker', (ctx) => {
    console.log(ctx.update.message.sticker);
})




bot.action("zakaz", async ctx => {
    await ctx.answerCbQuery()
    await ctx.replyWithHTML("About zakaz", Markup.keyboard([
        ['contact', 'location']
    ]).resize())
    
  })

bot.launch()

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));