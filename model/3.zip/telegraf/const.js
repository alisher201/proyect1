const commands = `
/start - boshlash
/help - yordam
/foods - ovqatlar
/drinks - ichimliklar
`

module.exports.commands = commands