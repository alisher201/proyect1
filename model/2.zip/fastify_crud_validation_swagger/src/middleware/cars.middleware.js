const { getCarValidation, updateValidation, createValidation } = require("../validation/cars_validation")


const carValidate = function(req, res, next){
   console.log(req.params);
    const { error } = getCarValidation(req.params)
   
   if(error){
    console.log(error.details[0].message, 'test.....');
      return res.send({msg: error.details[0].message})
   }
   next()
}

const updateValidate = function(req, res, next){
   console.log(req.params);

    const { error } = updateValidation({ id: req.params.id, ...req.body})
   
   if(error){
    console.log(error);
      return res.send({msg: error.details[0].message})
   }
   next()

}

const createValidate = function(req, res, next){
    const { error } = createValidation(req.body)
   
   if(error){
    console.log(error);
      return res.send({msg: error.details[0].message})
   }
   next()

}


module.exports = {
   carValidate,
   updateValidate,
   createValidate
}