const Joi = require("joi")

exports.getCarValidation = (car_id) => {

    const schema = Joi.object({
        id: Joi.number().required()
    })

    return schema.validate(car_id)
}

exports.updateValidation = (data) => {

    const schema = Joi.object({
        id: Joi.string().required(),
        title: Joi.string().required(),
        brand: Joi.string().required(),
        price: Joi.number().required(),
    })

    return schema.validate(data)
}

exports.createValidation = (data) => {

    const schema = Joi.object({
        title: Joi.string().required(),
        brand: Joi.string().required(),
        price: Joi.string().required(),
    })

    return schema.validate(data)
}