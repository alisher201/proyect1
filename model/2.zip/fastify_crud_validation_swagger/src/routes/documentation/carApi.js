const addCarSchema = {
  description: 'Create a new car',
  tags: ['cars'],
  summary: 'Creates new car with given values',
  body: {
    type: 'object',
    properties: {
      title: { type: 'string',  },
      brand: { type: 'string' },
      price: { type: 'string' }
    }

  },
  response: {
    200: {
      description: 'Successful response',
      type: 'object',
      properties: {
        id: { type: 'string'},
        title: { type: 'string' },
        brand: { type: 'string' },
        price: { type: 'string' }
      }
    }
  }
}

const getCarsSchema = {
  description: 'Get cars',
  tags: ['cars'],
  summary: 'Cars list'
}

const getCarSchema = {
  description: 'Get car',
  tags: ['cars'],
  summary: 'get car by id',
  body: {
    type: 'object',
    properties: {
      id: { type: 'string',  }
    }

  },
  response: {
    200: {
      description: 'Successful response',
      type: 'object',
      properties: {
        id: { type: 'string'},
        title: { type: 'string' },
        brand: { type: 'string' },
        price: { type: 'string' }
      }
    }
  }
}

const deleteCarSchema = {
  description: 'Delete car',
  tags: ['cars'],
  summary: 'delete car by id',
  body: {
    type: 'object',
    properties: {
      id: { type: 'string',  }
    }

  },
  response: {
    200: {
      description: 'Successful response',
      type: 'object',
      properties: {
        id: { type: 'string'}
      }
    }
  }
}

const updateCarSchema = {
  description: 'update a new car',
  tags: ['cars'],
  summary: 'Update car by id',
  body: {
    type: 'object',
    properties: {
      car_id: { type: 'string' },
      title: { type: 'string' },
      brand: { type: 'string' },
      price: { type: 'string' }
    }

  },
  response: {
    200: {
      description: 'Successful response',
      type: 'object',
      properties: {
        car_id: { type: 'string'},
        title: { type: 'string' },
        brand: { type: 'string' },
        price: { type: 'string' }
      }
    }
  }
}

module.exports = {
  addCarSchema,
  getCarSchema,
  deleteCarSchema,
  updateCarSchema,
  getCarsSchema
}

