// Import our Controllers
const carController = require('../controllers/carController')
const { carValidate, updateValidate, createValidate } = require('../middleware/cars.middleware')

// Import Swagger documentation
 const documentation = require('./documentation/carApi')



async function routes(fastify, options){
    fastify
          .get('/:id', {
            schema: {
                description: 'This is an endpoint for fetching a car by id',
                tags: ['cars'],
                params: {
                    description: 'Car Id',
                    type: 'object',
                    properties: {
                        id: { type: 'string' } 
                    }
                },
                response: {
                    200: {
                        description: 'Success Response',
                        type: 'object',
                        properties: {
                            id: { type: 'string' },
                            title: { type: 'string' },
                            brand: { type: 'string' },
                            price: { type: 'string' }
                        }                  
                    },
                    404: {
                        description: 'Not found',
                        properties: {
                            id: { type: 'string' }
                        } 
                    }
                }
            },
            beforeHandler: [carValidate] }, carController.getSingleCar)
          .delete('/:id', { beforeHandler: [carValidate] }, carController.deleteCar)
          .put('/:id', { beforeHandler: [updateValidate] }, carController.updateCar)
          .post('/car',  { beforeHandler: [createValidate] }, carController.addCar )
          .get('/cars', carController.getCars )

          fastify.get('/', {
            schema: {
                description: 'This is an endpoint for application health check',
                tags: ['health'],
                response: {
                    200: {
                        description: 'Success Response',
                        type: 'object',
                        properties: {
                            msg: { type: 'string' }
                        }
                    }
                }
            }
        }, (request, reply) => {
            reply.send({ msg: "The Application is Up and Running" })
        })



    
         

}

module.exports = routes
