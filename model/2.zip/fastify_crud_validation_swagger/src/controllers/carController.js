// External Dependancies
const boom = require('boom')
const { read_file, write_file } = require('../fs/fs_api')



// Get all cars
exports.getCars = async (req, reply) => {
  try {
    const cars = read_file("cars.json")
    reply.send(cars)
  } catch (err) {
    throw boom.boomify(err)
  }
}

// Get single car by ID
exports.getSingleCar = async (req, reply) => {
  try {
    console.log(req.params);
    const id = req.params.id
    const car = read_file("cars.json").find(c => c.id == id)
    reply.send(car)
  } catch (err) {
    throw boom.boomify(err)
  }
}

// Add a new car
exports.addCar = async (req, reply) => {
  try {
    const cars = read_file('cars.json')
    let car = {
      id: cars.length + 1,
      ...req.body
    }
    cars.push(car)
    write_file("cars.json", cars)

    reply.send(car)
  } catch (err) {
    throw boom.boomify(err)
  }
}

// Update an existing car
exports.updateCar = async (req, reply) => {
  try {
   
    const car = req.body
    const { id, ...updateData } = car
    const cars = read_file("cars.json")

    cars.forEach(c => {
      if(c.id == id){
        c.title = updateData.title
        c.price = updateData.price
        c.brand = updateData.brand
      }
    })

    write_file("cars.json", cars)
    reply.send(update)
  } catch (err) {
    throw boom.boomify(err)
  }
}

// Delete a car
exports.deleteCar = async (req, reply) => {
  try {
    const id = req.params.id
    const cars = read_file("cars.json")

    cars.forEach((car, idx) => {
      if(car.id == id){
        cars.splice(idx, 1)
      }
    })

    write_file("cars.json", cars)
    reply.send({
      msg: 'Deleted car'
    })
  } catch (err) {
    throw boom.boomify(err)
  }
}
