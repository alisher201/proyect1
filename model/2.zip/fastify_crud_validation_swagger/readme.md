# A blazing fast REST APIs with Node.js, MongoDB, Fastify and Swagger.

> A Node.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm start
```
## Prerequisites
- Nodejs
- MongoDB

## Tutorial on Medium

https://medium.freecodecamp.org/how-to-build-blazing-fast-rest-apis-with-node-js-mongodb-fastify-and-swagger-114e062db0c9
